import os
from PIL import Image
LOCAL = os.path.dirname(os.path.realpath(__file__))

os.makedirs(os.path.join(LOCAL, 'icon'), exist_ok=True)

for file in os.listdir(LOCAL):
    if file.endswith('.png'):
        src_path = os.path.join(LOCAL, file)
        print(src_path)
        img = Image.open(src_path)

        # ICON
        img.resize((24,24), Image.NEAREST).save(os.path.join(LOCAL,'icon', file), format='png')