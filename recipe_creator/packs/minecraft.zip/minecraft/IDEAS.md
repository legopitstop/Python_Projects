# IDEAS

- Recipe Advancement codec
- menus with these names will be used depending on the context.
    - `input_context`
    - `outliner_context`
    - `slot_context`
    - `root`

- registries with the `minecraft` namespace can be called without the namespace `minecraft:test_item` == `test_item`