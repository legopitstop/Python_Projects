import os
import json
LOCAL = os.path.dirname(os.path.realpath(__file__))

with open(os.path.join(LOCAL, 'item_textures.json'), 'r') as item_textures:
    data = json.load(item_textures)

    for file in os.listdir(os.path.join(LOCAL, 'textures', 'item')):
        print(file)
        name = file.replace('.png', '')
        data['texture_data'][name] = {'textures': 'minecraft:item/%s'%(name)}

    #save
    with open(os.path.join(LOCAL, 'item_textures.json'), 'w') as w: w.write(json.dumps(data))