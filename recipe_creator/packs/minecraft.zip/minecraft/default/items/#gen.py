# Create all items

import json
import requests, os

LOCAL = os.path.dirname(os.path.realpath(__file__))


items = requests.get('https://legopitstop.github.io/JSON-Schemas/minecraft/java/item.json').json()

for item in items['examples']:
    filename = item.replace('minecraft:', '')
    obj = {
        'icon': item,
        'max_count': 64,
        'identifier_type': {
            'java': item,
            'bedrock': {
                'id': item,
                'data': 0
            }
        },
        'creative_category': {
            'category': 'misc'
        }
    }
    print(filename)

    wrt = open(os.path.join(LOCAL,filename+'.json'), 'w')
    wrt.write(json.dumps(obj, indent=4))
    wrt.close()
